import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { NgxPaginationModule } from 'ngx-pagination';

export const sharedDeclarationsWithIcons = [
  CommonModule,
  FormsModule,
  RouterModule,
  FontAwesomeModule,
  // TypeaheadModule,
  BsDropdownModule,
  NgxPaginationModule,
  TabsModule,
  TooltipModule,
];

export const sharedDeclarations = [
  CommonModule,
  FormsModule,
  NgxPaginationModule,
  TooltipModule,
];
