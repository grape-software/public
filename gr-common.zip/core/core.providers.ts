import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { importProvidersFrom } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { provideToastr } from 'ngx-toastr';

export const sharedProviders = [
  provideToastr(),
  importProvidersFrom(RouterModule, FormsModule, ReactiveFormsModule, BrowserAnimationsModule),
  BsModalService,
];
