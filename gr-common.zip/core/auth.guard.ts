import { Router, RouterStateSnapshot } from '@angular/router';

export function authGuard(router: Router) {
  return (state: RouterStateSnapshot) => {
    const u = localStorage.getItem('user');
    if (!u) {
      router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
      return false;
    } else {
      const user = JSON.parse(u);
      if (user) {
        // user is logged
        return true;
      } else {
        router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
        return false;
      }
    }
  };
}
