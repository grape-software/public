import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { NgxPaginationModule } from 'ngx-pagination';

export const sharedDeclarationsWithIcons = [
  CommonModule,
  FormsModule,
  NgxPaginationModule,
  FontAwesomeModule,
  TooltipModule,
  BsDropdownModule,
];

export const sharedDeclarations = [CommonModule, FormsModule, NgxPaginationModule, TooltipModule];
