import * as jsonData from '../../public/web-init.json';

import { APP_INITIALIZER, ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

import { AUTH_ROUTES } from './auth/auth.routes';
import { CONFIG_ROUTES } from './config/config.routes';
import { DOCUMENT } from '@angular/common';
import { TenantsService } from './services/tenants.service';
import { TokenInterceptor } from './core/http-interceptor.interceptor';
import { WebConfig } from './WebConfig';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideRouter } from '@angular/router';
import { provideToastr } from 'ngx-toastr';
import { routes } from './app.routes';
import { sharedProviders } from './core/core.providers';

function initializeAppFactory(tenantsService: TenantsService, document: Document): () => Observable<any> {
  return () =>
    tenantsService.getInfoFromUrl('WEB-INIT').pipe(
      tap((r: any) => {
        const config = Object.assign(new WebConfig(), jsonData); // jsonData as WebConfig;
        if (r && r.length > 0) {
          const webInitParam = Object.assign(new WebConfig(), JSON.parse(r[0].value));
          if (webInitParam) {
            Object.assign(config, webInitParam); // hace un merge de los atributos de webInitParam en config
          }
          config.tenantId = r[0].tenantId;
        }
        tenantsService.config = config; // para actualizar lo que se leyo de la base
        localStorage.setItem('webConfig', JSON.stringify(config));
        if (config.styleSheetName) {
          const styleLink = document.createElement('link');
          styleLink.rel = 'stylesheet';
          if (config.styleSheetName.startsWith('http')) {
            styleLink.href = config.styleSheetName;
          } else {
            styleLink.href = `assets/css/${config.styleSheetName}.css`;
          }
          document.head.appendChild(styleLink);
        }
      }),
    );
}

export const appConfig: ApplicationConfig = {
  providers: [
    provideAnimations(), // required animations providers
    provideToastr({}),
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter([...routes, ...CONFIG_ROUTES, ...AUTH_ROUTES]),
    // provideRouter(routes),
    // provideAppInitializer(() => initializeAppFactory(inject(TenantsService))),
    ...sharedProviders,
    {
      provide: APP_INITIALIZER,
      useFactory: initializeAppFactory,
      deps: [TenantsService, DOCUMENT],
      multi: true,
    },
    provideHttpClient(
      // DI-based interceptors must be explicitly enabled.
      withInterceptorsFromDi(),
    ),
    { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true },
  ],
};
