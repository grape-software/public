import { DOCUMENT } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import * as jsonData from '../../../public/web-init.json';
import { HelperService } from './helper.service';

@Injectable({
  providedIn: 'root',
})
export class TenantsService {
  // TODO: tiene que ser un observable
  config: any;

  constructor(
    private http: HttpClient,
    private helpers: HelperService,
    @Inject(DOCUMENT) private document: Document,
  ) {
    this.config = jsonData;
    // this.getInfoFromUrl('WEB-INIT').subscribe({
    //   next: (r: any) => {
    //     if (r.length > 0) {
    //       const webInitParam = JSON.parse(r[0].value);
    //       if (webInitParam) {
    //         this.config = webInitParam;
    //       }
    //     }
    //   },
    // });
  }
  getConfig: any = () => {
    return this.config;
  };
  setConfig: any = (config: any) => {
    this.config = config;
  };

  search(filters: any) {
    return this.http.get(`${environment.coreUrl}/tenants`, {
      params: this.helpers.createHttpParams(filters),
    });
  }
  getInfo(id: any, filters: any) {
    return this.http.get(`${environment.coreUrl}/tenants/${id}/info`, {
      params: this.helpers.createHttpParams(filters),
    });
  }
  getInfoFromUrl(filter: any) {
    let filters;
    if (filter) filters = { code: filter, url: this.document.location.origin };
    else filters = { url: this.document.location.origin };
    return this.http.get(`${environment.coreUrl}/tenants/info-from-url`, {
      params: this.helpers.createHttpParams(filters),
    });
  }
  getLogo(url: string) {
    // if (!url) return '';
    // if (url.startsWith('http')) return url;
    return this.http.get(`${environment.coreUrl}${url}`);
  }
}
