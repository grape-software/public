import { EventEmitter, Injectable, Output } from '@angular/core';

import { HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root',
})
export class HelperService {
  constructor(
    private router: Router,
    private toastr: ToastrService,
  ) {}
  public createHttpParams(p: any): HttpParams {
    if (p == null || p === undefined) {
      throw new Error('Parameter not found');
    }
    let httpParams: HttpParams = new HttpParams();
    Object.keys(p).forEach((param) => {
      if (p[param] != undefined && p[param] != null) {
        // if it's bool param and is set to false should be passed
        if (Array.isArray(p[param])) {
          p[param].forEach((element: string | number | boolean) => {
            httpParams = httpParams.append(param, element);
          });
        } else {
          httpParams = httpParams.append(param, p[param]);
        }
      }
    });

    return httpParams;
  }

  public getUrlName(url: string) {
    // url con: /admin/carreras/planesEstudio;carreraId=1
    let stringsplit = url.split(';');
    // url con: /admin/carreras/planesEstudio?carreraId=1
    stringsplit = stringsplit[0].split('?');
    let result = stringsplit[0].split('/').join('.');
    if (result.startsWith('.')) {
      result = result.substring(1, result.length);
    }
    return result;
  }

  //#region guarda los filtros de busqueda en localStorage
  saveToStorage(key: string, obj: any) {
    if (key && obj) {
      if (typeof obj !== 'string') {
        localStorage.setItem(key, JSON.stringify(obj));
      } else {
        localStorage.setItem(key, obj);
      }
    }
  }
  //#endregion
  //#region obtiene los filtros de busqueda de localStorage
  getOrDefaultSearchFromStorage(key: string): any {
    const defaultConfig = {
      pageSize: 10,
      sortValue: 'asc',
      //sortKey: defaultSortKey,
      pageIndex: 1,
      totalCount: 0,
      searching: false,
      //searchText: '',
      //fromDate:{year: desde.getFullYear(), month:desde.getMonth()+1, day:desde.getDate()},
      //toDate:{year: ahora.getFullYear(), month:ahora.getMonth()+1, day:ahora.getDate()},
    };

    const objStr = localStorage.getItem(key);
    if (!objStr) return defaultConfig;
    try {
      const obj = JSON.parse(objStr);
      return obj;
    } catch {
      return defaultConfig;
    }
  }
  getLastSearchFromStorage(key: string): any {
    const objStr = localStorage.getItem(key);
    if (!objStr) return null;
    const obj = JSON.parse(objStr);
    return obj;
  }
  removeMenuFilters() {
    for (let i = 0; i < localStorage.length; i++) {
      if (localStorage.key(i)?.startsWith('search.')) localStorage.removeItem(localStorage.key(i) ?? '');
    }
  }

  //region: Administración de errores y notificaciones
  @Output() newNotification: EventEmitter<number> = new EventEmitter();
  public notifEvents: any[] = [];

  /**
   * Handles a non successful http response. Notifications will be raised acording the status code
   * @param httpResponse - Instance of HttpResponseMessage
   * @param codeLocation - (Optional) String indicating the location of the error in the code
   * @param forbidenMessageAppend - (Optional) Message to append after 'No tiene el permiso necesario
   *    para ejeutar la acción deseada. Si considera que esto es un error contáctese con administración. '
   * @param unexpectedErrorMessageAppend - (Optional) Message to append after 'Surgió un error inesperado.
   *    Intente nuevamente. Si el problema persiste comuníquese con soporte. '
   * @version 1.0
   */
  public HandleNonSuccessfulHttpResponse(
    httpResponse: any,
    codeLocation?: string,
    forbidenMessageAppend?: string,
    unexpectedErrorMessageAppend?: string,
  ): void {
    if (!codeLocation) {
      codeLocation = '';
    }
    if (codeLocation && codeLocation.length > 0) {
      codeLocation = '[' + codeLocation + '] ';
    }

    if (httpResponse.status === 400) {
      // Handle badrequest
      //console.warn(codeLocation + 'Error: ' + httpResponse.error, httpResponse);
      this.RaiseNotification('warning', 'Error', httpResponse.error);
    } else if (httpResponse.status === 401) {
      // Handle unauthorized
      //console.warn(codeLocation + 'Error de autenticación', httpResponse);
      // eslint-disable-next-line max-len
      this.RaiseNotification(
        'warning',
        'Error de autenticación',
        'No se ha podido determinar su identidad. Por favor, vuelva a iniciar sesión.',
      );
      localStorage.removeItem('user');
      this.router.navigate(['login']);
    } else if (httpResponse.status === 403) {
      // Handle forbiden
      //console.warn(codeLocation + 'Permiso faltante: ' + httpResponse.error, httpResponse);
      // eslint-disable-next-line max-len
      this.RaiseNotification(
        'warning',
        'Permiso faltante',
        'No tiene el permiso necesario para ejeutar la acción deseada. Si considera que esto es un error contáctese con administración. ' +
          (forbidenMessageAppend ? forbidenMessageAppend : ''),
      );
    } else if (httpResponse.status === 404) {
      // Handle resource not found
      //console.warn(codeLocation + 'Recurso no encontrado', httpResponse);
      // eslint-disable-next-line max-len
      this.RaiseNotification(
        'error',
        'Recurso no encontrado',
        'El recurso al que está intentando acceder no existe o fue eliminado.',
      );
    } else if (httpResponse.status === 0) {
      // Handle server unreachable
      //console.warn(codeLocation + 'Sin conexión', httpResponse);
      // eslint-disable-next-line max-len
      this.RaiseNotification(
        'error',
        'Sin conexión',
        'No se pudo acceder al servidor. Verifique su conexión a internet o comuníquese con soporte.',
      );
    } else {
      // Handle unknown error
      //console.error(codeLocation + 'Error inesperado', httpResponse);
      // eslint-disable-next-line max-len
      this.RaiseNotification(
        'error',
        'Error inesperado',
        'Surgió un error inesperado. Intente nuevamente. Si el problema persiste comuníquese con soporte. ' +
          (unexpectedErrorMessageAppend ? unexpectedErrorMessageAppend : ''),
      );
    }
  }

  /**
   * Muestra una notificación en toast y agrega al array de notificaciones emitiendo un evento para el panel de notificaciones
   * Posibles valores de type: basic, primary, success, danger, warning, info, control
   */
  public RaiseNotification(
    type: any,
    title: string,
    content: string,
    timeMs = 3000,
    // handler?: string
  ): void {
    const options = { timeOut: timeMs };
    if (type === 'success') {
      this.toastr.success(content, title, options);
    }
    if (type === 'danger') {
      this.toastr.error(content, title, options);
    }
    if (type === 'warning') {
      this.toastr.warning(content, title, options);
    }
    const newEvent = {
      when: new Date(),
      type,
      title,
      content,
      timeMs,
    };
    this.notifEvents = [newEvent, ...this.notifEvents];
    // Dispara la notificación para el top-bar que pueda poner las cantidades de nootificaciones sin leer
    this.newNotification.emit(this.notifEvents.length);
  }

  //endregion
  getDate(days: number) {
    const d = new Date();
    d.setDate(d.getDate() + days);
    const r = d.getFullYear() + '-' + this.pad(d.getMonth() + 1) + '-' + this.pad(d.getDate());
    return r;
  }
  fechaDias(dias: any) {
    const d = new Date();
    d.setDate(d.getDate() + dias);
    const r = d.getFullYear() + '-' + this.pad(d.getMonth() + 1) + '-' + this.pad(d.getDate());
    return r;
  }

  pad(number: number) {
    if (number < 10) {
      return '0' + number;
    }
    return number;
  }
  toISOLocal(d: any) {
    const z = (n: string | number) => ('0' + n).slice(-2);
    const zz = (n: string) => ('00' + n).slice(-3);
    let off = d.getTimezoneOffset();
    const sign = off > 0 ? '-' : '+';
    off = Math.abs(off);

    return (
      d.getFullYear() +
      '-' +
      z(d.getMonth() + 1) +
      '-' +
      z(d.getDate()) +
      'T' +
      z(d.getHours()) +
      ':' +
      z(d.getMinutes()) +
      ':' +
      z(d.getSeconds()) +
      '.' +
      zz(d.getMilliseconds()) +
      sign +
      z((off / 60) | 0) +
      ':' +
      z(off % 60)
    );
  }
  private urlBase64Decode(str: string) {
    let output = str.replace(/-/g, '+').replace(/_/g, '/');
    switch (output.length % 4) {
      case 0:
        break;
      case 2:
        output += '==';
        break;
      case 3:
        output += '=';
        break;
      default:
        // tslint:disable-next-line:no-string-throw
        throw 'Illegal base64url string!';
    }
    return decodeURIComponent((<any>window).escape(window.atob(output)));
  }
  getTenantId(): any {
    const userString = localStorage.getItem('user');
    if (userString) {
      const user = JSON.parse(userString);
      // Decode token
      if (user.token) {
        const parts = user.token.split('.');
        if (parts.length !== 3) {
          throw new Error('JWT must have 3 parts');
        }
        const decoded = this.urlBase64Decode(parts[1]);
        if (!decoded) {
          throw new Error('Cannot decode the token');
        }
        const claims = JSON.parse(decoded);
        if (claims) {
          return claims.tenantId;
        } else {
          return 0;
        }
      }
    }
  }
  fecha() {
    const d = new Date();
    const r = d.getFullYear() + '-' + this.pad(d.getMonth() + 1) + '-' + this.pad(d.getDate());
    return r;
  }
  userHasRol(rol: string): boolean {
    let ret = false; //Por default no tiene el rol
    const userString = localStorage.getItem('user');
    if (userString) {
      const user = JSON.parse(userString);
      if (user.userRol.find((x: any) => x.rol.name == rol) != null) ret = true;
    }
    return ret;
  }
  getEmpresaId(): any {
    const userString = localStorage.getItem('user');
    if (userString) {
      const user = JSON.parse(userString);
      // Decode token
      if (user.token) {
        const parts = user.token.split('.');
        if (parts.length !== 3) {
          throw new Error('JWT must have 3 parts');
        }
        const decoded = this.urlBase64Decode(parts[1]);
        if (!decoded) {
          throw new Error('Cannot decode the token');
        }
        const claims = JSON.parse(decoded);
        if (claims) {
          return claims.empresaId;
        } else {
          return 0;
        }
      }
    }
  }
  //Ultimo dia de cualquier mes
  //si el dia es cero esto indica ultimo dia de mes especificado
  /*endDayMonth(mes: any, dia: any): Number {
    if (dia == 0 && mes == null) {
      //ultimo dia mes actual de año actual
      let aux = new Date();
      let endDay;
      endDay = new Date(aux.getFullYear(), aux.getMonth() + 1, 0);
      return endDay.getDate();
    }
    if (dia == 0 && mes != 0) {
      // ultimo dia de cualqueir mes de año actual
      let aux = new Date();
      let endDay;
      endDay = new Date(aux.getFullYear(), aux.getMonth() + mes, 0);
      return endDay.getDate();
    }
  }*/
  //permite especificar una fecha (incluidos ultimos dias mes), de lo contrario retorna fecha actual.
  fechaAdaptada(año?: any, mes?: any, dia?: any) {
    const fecha = new Date();
    let year,
      months,
      days = 0;

    if (año != null && año != 0) {
      fecha.setFullYear(año);
      year = fecha.getFullYear();
    } else {
      year = fecha.getFullYear();
    }
    if (mes != null) {
      mes = mes - 1;
      fecha.setMonth(mes);
      months = fecha.getMonth();
    } else {
      months = fecha.getMonth();
    }
    if (dia != null && dia != 0) {
      fecha.setDate(dia);
      days = fecha.getDate();
    } else {
      if (dia == null) {
        days = fecha.getDate();
      }
    }
    const retorno = year + '-' + this.pad(months + 1) + '-' + this.pad(days);
    return retorno;
  }
  useId(): any {
    const userString = localStorage.getItem('user') ?? '';
    const user = JSON.parse(userString);
    return user.userId;
  }
}
