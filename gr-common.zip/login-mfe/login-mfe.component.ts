import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthGeneralService } from '../services/auth-general.service';
import { HelperService } from '../services/helper.service';
import { sharedDeclarations } from '../shared/shared-declarations';

@Component({
  selector: 'app-login-mfe',
  templateUrl: './login-mfe.component.html',
  styleUrls: ['./login-mfe.component.scss'],
  imports: [...sharedDeclarations],
})
export class LoginMfeComponent {
  working = false;
  userEmail: any;
  userPassword: any;

  constructor(
    private router: Router,
    private helpers: HelperService,
    private authService: AuthGeneralService,
  ) {}

  login() {
    this.working = true;
    this.authService.Login(this.userEmail, this.userPassword).subscribe({
      next: (authResp: any) => {
        this.working = false;
        let localUser: any;
        // fixes because version 1.0 of Auth backend (compatibility old apis)
        if (authResp.user != undefined && authResp.user != null) {
          localUser = authResp.user;
          localUser.token = authResp.jwtToken;
          localUser.authProvider = authResp.authProvider;
          localUser.isAdmin = authResp.isAdmin;
        } else {
          // version 2.0 of Auth backend
          localUser = authResp;
        }

        localStorage.setItem('user', JSON.stringify(localUser));
        // this.userSubject.next(localUser);
        this.router.navigate(['/']);
      },
      error: (e) => {
        this.working = false;
        this.helpers.RaiseNotification(
          'danger',
          'Login',
          // $localize`:@@ErrorGenerico:Error al intentar ingresar ${e.error?.Message ?? e}`,
          `Error al intentar ingresar ${e.error?.Message ?? e}`,
        );
      },
    });
  }
}
