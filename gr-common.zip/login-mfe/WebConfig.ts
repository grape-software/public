export class WebConfig {
  customHome: string = '';
  favIcon: string = '';
  title: string = '';
  tenantId: string = '';
  styleSheetName: string = '';
  logoUrl: string = '';
  backgroundUrl: string = '';
  menuConGrupos: boolean = false;
  homeTitle: string = '';
  homeUrl: string = '';
}
