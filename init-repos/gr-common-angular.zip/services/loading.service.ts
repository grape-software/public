import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
/*
Servicio para manejar el estado de carga global de la aplicación y la inicialización de la misma.
 */
export class LoadingService {
  // Estados de carga global (signals)
  isLoading = signal(false);
  loadingText = signal('Cargando...');
  errorMessage = signal('');
  isInitialized = signal(false);
  // private loadingTimeout: any = null;
  // private pendingLoading = false;

  // // Estados de inicialización de la app (signals)
  // private _isInitialized = signal(false);
  // private _isInitializing = signal(false);

  // Signals de solo lectura (readonly)
  // readonly isLoading = this._isLoading.asReadonly();
  // readonly loadingText = this._loadingText.asReadonly();
  // readonly isInitialized = this._isInitialized.asReadonly();
  // readonly isInitializing = this._isInitializing.asReadonly();

  // getIsLoading(): boolean {
  //   return this._isLoading();
  // }

  // getLoadingText(): string {
  //   return this._loadingText();
  // }

  startLoading(text?: string) {
    if (text) {
      this.loadingText.set(text);
    }

    // Si ya hay un timeout pendiente, no hacer nada
    // if (this.loadingTimeout) {
    //   this.pendingLoading = true;
    //   return;
    // }

    // Si ya está cargando, no hacer nada
    // if (this._isLoading()) {
    //   return;
    // }

    // this.pendingLoading = true;

    this.isLoading.set(true);

    // Retrasar la visualización del spinner por 1 segundo
    // this.loadingTimeout = setTimeout(() => {
    //   if (this.pendingLoading) {
    //     this._isLoading.set(true);
    //   }
    //   this.loadingTimeout = null;
    // }, 1000);
  }

  stopLoading() {
    // Limpiar el timeout si existe
    // if (this.loadingTimeout) {
    //   clearTimeout(this.loadingTimeout);
    //   this.loadingTimeout = null;
    // }

    // this.pendingLoading = false;
    this.isLoading.set(false);
  }

  setLoadingText(text: string) {
    this.loadingText.set(text);
  }

  // // Métodos para inicialización de la app
  // setInitializing(isInitializing: boolean): void {
  //   this._isInitializing.set(isInitializing);
  // }

  // setInitialized(isInitialized: boolean): void {
  //   this._isInitialized.set(isInitialized);
  //   if (isInitialized) {
  //     this._isInitializing.set(false);
  //   }
  // }
}
