import { BehaviorSubject, Observable } from 'rxjs';

import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class AuthGeneralService {
  menus: MenuItem[] = [];

  private router = inject(Router);
  private http = inject(HttpClient);

  private userSubject: BehaviorSubject<User>;

  public user: Observable<User>;

  constructor() {
    // link user variable
    this.userSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('user') || '{}'));
    this.user = this.userSubject.asObservable();
  }

  public get userValue(): User {
    return this.userSubject.value;
  }

  forgetPassword(params: any) {
    return this.http.put(`${environment.coreUrl}/auth/forget-password`, {
      email: params.userEmail,
    });
  }

  Login(identifier?: string, password?: string) {
    return this.http.post(`${environment.coreUrl}/auth/login`, {
      Identifier: identifier,
      Password: password,
    });
  }

  SignOut() {
    // Borro data del usuario
    localStorage.removeItem('user');
    this.userSubject.next({} as User);
    this.router.navigate(['/login']);
  }

  /**
   * Carga el menú para el usuario
   */
  getAccess() {
    return this.http.get(`${environment.coreUrl}/auth/myaccess`);

    // this.http.get(environment.coreUrl + `/auth/myaccess`)
    //   .subscribe((res: any) => {
    //     if (res != undefined && res != null) {
    //       this.menus = res.menus;
    //     }
    //     this.menus.push({
    //       menuId: 0,
    //       name: 'Home',
    //       icon: 'home',
    //       url: '/',
    //       group: '',
    //       order: 0,
    //     });
    //   });
  }

  resetPassword(newPassword: any) {
    return this.http.put(`${environment.coreUrl}/auth/reset-pass`, {
      password: newPassword,
    });
  }
}
interface MenuItem {
  menuId: number;
  name: string;
  group: string;
  order: number;
  url: string;
  icon: string;
  // fullName: string;
}
interface User {
  userId: number;
  identifier: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  timeZoneId: string;
  timeZoneDiffHours: string;
  langId: string;
  fullName: string;
  gender: string;
  token: string;
  authProvider: string;
  isAdmin: boolean;
}
