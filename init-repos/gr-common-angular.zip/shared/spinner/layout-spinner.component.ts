import { Component, Input, inject } from '@angular/core';

import { CommonModule } from '@angular/common';
import { LoadingService } from 'src/app/services/loading.service';

@Component({
  selector: 'app-spinner',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './layout-spinner.component.html',
  styleUrls: ['./layout-spinner.component.scss'],
})
export class LayoutSpinnerComponent {
  @Input() size: 'small' | 'medium' | 'large' = 'medium';
  @Input() color: 'primary' | 'success' | 'warning' | 'danger' | 'info' = 'primary';
  @Input() text = '';
  @Input() percentage: number | null = null;
  @Input() overlay = false;
  public loadingService = inject(LoadingService);
}
