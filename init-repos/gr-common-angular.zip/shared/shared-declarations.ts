import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import {
  ButtonModule,
  DropdownModule,
  ModalModule,
  TabsModule,
  TooltipModule,
} from '@coreui/angular';
import { NgxPaginationModule } from 'ngx-pagination';

export const sharedDeclarationsWithIcons = [
  CommonModule,
  FormsModule,
  RouterModule,
  MatIconModule,
  // TypeaheadModule,
  DropdownModule,
  NgxPaginationModule,
  TabsModule,
  TooltipModule,
  ButtonModule,
  ModalModule,
];

export const sharedDeclarations = [CommonModule, FormsModule, NgxPaginationModule, TooltipModule];
