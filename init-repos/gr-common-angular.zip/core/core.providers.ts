import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { importProvidersFrom } from '@angular/core';
import { provideAnimations } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { ModalService } from '@coreui/angular';
import { provideToastr } from 'ngx-toastr';

export const sharedProviders = [
  provideAnimations(),
  provideToastr(),
  importProvidersFrom(RouterModule, FormsModule, ReactiveFormsModule),
  ModalService,
];
