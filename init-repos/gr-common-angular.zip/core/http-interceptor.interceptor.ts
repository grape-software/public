import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandlerFn,
  HttpInterceptorFn,
  HttpRequest,
} from '@angular/common/http';
import { Observable, catchError, finalize, throwError } from 'rxjs';

import { DOCUMENT } from '@angular/common';
import { LoadingService } from '../services/loading.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { inject } from '@angular/core';

let totalRequests = 0;

export const tokenInterceptor: HttpInterceptorFn = (
  request: HttpRequest<unknown>,
  next: HttpHandlerFn,
): Observable<HttpEvent<unknown>> => {
  const document = inject(DOCUMENT);
  const loadingService = inject(LoadingService);
  const router = inject(Router);

  let newUrl = request.url;
  // change url origin with set in browser url
  // only affect when useBrowserUrl is set to true
  if (environment.useBrowserUrl) {
    const browserOrigin = document.location.origin;
    const currentOrigin = new URL(request.url).origin;
    newUrl = newUrl.replace(currentOrigin, browserOrigin);
  }
  // sets x-api-key header from tenantId
  const configString = localStorage.getItem('webConfig');
  let xapikey = '';
  if (configString) {
    const config = JSON.parse(configString);
    xapikey = config.tenantId;
  }

  const userString = localStorage.getItem('user');
  let isLoggedIn = false;
  let user: { token: string } | null = null;
  if (userString) {
    user = JSON.parse(userString);
    isLoggedIn = !!(user && user.token);
  }
  // const iscoreUrl = request.url.startsWith(environment.coreUrl);
  if (isLoggedIn && user) {
    // && iscoreUrl) {
    request = request.clone({
      url: newUrl,
      setHeaders: {
        Authorization: `Bearer ${user.token}`,
        version: environment.version,
        'x-api-key': xapikey,
      },
    });
  } else {
    request = request.clone({
      url: newUrl,
      setHeaders: {
        version: environment.version,
        'x-api-key': xapikey,
      },
    });
  }

  // Global loader
  totalRequests++;
  loadingService.startLoading('Cargando...');
  // console.log(totalRequests + '-' + request.url);

  return next(request).pipe(
    // TODO: 401 al login
    catchError((error: HttpErrorResponse) => {
      // console.log('err-' + totalRequests + '-' + request.url);
      totalRequests--;
      if (totalRequests <= 0) {
        totalRequests = 0;
        loadingService.stopLoading();
      }
      if (error.status === 401) {
        router.navigate(['/login']);
      }
      return throwError(() => error);
    }),
    finalize(() => {
      // console.log('fin-' + totalRequests + '-' + request.url);
      totalRequests--;
      if (totalRequests <= 0) {
        totalRequests = 0;
        loadingService.stopLoading();
      }
    }),
  );
};
