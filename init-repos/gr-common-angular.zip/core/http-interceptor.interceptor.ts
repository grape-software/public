import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';

import { DOCUMENT } from '@angular/common';
import { inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, finalize, Observable, throwError } from 'rxjs';
import { LoaderService } from 'src/app/services/loader.service';
import { environment } from 'src/environments/environment';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  private totalRequests = 0;
  private document = inject(DOCUMENT);
  private loadingService = inject(LoaderService);
  private router = inject(Router);
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let newUrl = request.url;
    // change url origin with set in browser url
    // only affect when useBrowserUrl is set to true
    if (environment.useBrowserUrl) {
      const browserOrigin = this.document.location.origin;
      const currentOrigin = new URL(request.url).origin;
      newUrl = newUrl.replace(currentOrigin, browserOrigin);
    }
    // sets x-api-key header from tenantId
    const configString = localStorage.getItem('webConfig');
    let xapikey = '';
    if (configString) {
      const config = JSON.parse(configString);
      xapikey = config.tenantId;
    }

    const userString = localStorage.getItem('user');
    let isLoggedIn = false;
    let user = null;
    if (userString) {
      user = JSON.parse(userString);
      isLoggedIn = user && user.token;
    }
    // const iscoreUrl = request.url.startsWith(environment.coreUrl);
    if (isLoggedIn && user) {
      // && iscoreUrl) {
      request = request.clone({
        url: newUrl,
        setHeaders: {
          Authorization: `Bearer ${user.token}`,
          version: environment.version,
          'x-api-key': xapikey,
        },
      });
    } else {
      request = request.clone({
        url: newUrl,
        setHeaders: {
          version: environment.version,
          'x-api-key': xapikey,
        },
      });
    }

    // Global loader
    this.totalRequests++;
    this.loadingService.setLoading(true);
    // console.log(this.totalRequests + '-' + request.url);

    return next.handle(request).pipe(
      // TODO: 401 al login
      catchError((error: HttpErrorResponse) => {
        // console.log('err-' + this.totalRequests + '-' + request.url);
        this.totalRequests--;
        if (this.totalRequests <= 0) {
          this.totalRequests = 0;
          this.loadingService.setLoading(false);
        }
        if (error.status === 401) {
          this.router.navigate(['/login']);
        }
        return throwError(() => error);
      }),
      finalize(() => {
        // console.log('fin-' + this.totalRequests + '-' + request.url);
        this.totalRequests--;
        if (this.totalRequests <= 0) {
          this.totalRequests = 0;
          this.loadingService.setLoading(false);
        }
      }),
    );
  }
}
