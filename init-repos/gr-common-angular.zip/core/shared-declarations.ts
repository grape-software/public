import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DropdownModule, TooltipModule } from '@coreui/angular';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { NgxPaginationModule } from 'ngx-pagination';

export const sharedDeclarationsWithIcons = [
  CommonModule,
  FormsModule,
  NgxPaginationModule,
  FontAwesomeModule,
  TooltipModule,
  DropdownModule,
];

export const sharedDeclarations = [CommonModule, FormsModule, NgxPaginationModule, TooltipModule];
