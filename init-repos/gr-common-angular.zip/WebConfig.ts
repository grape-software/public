export class WebConfig {
  customHome = '';
  favIcon = '';
  title = '';
  tenantId = '';
  styleSheetName = '';
  logoUrl = '';
  menuConGrupos = false;
  homeTitle = '';
  homeUrl = '';
  resetLastSearchOnMainMenu = false;
}
