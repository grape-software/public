import { provideHttpClient, withInterceptors } from '@angular/common/http';
import {
  ApplicationConfig,
  importProvidersFrom,
  inject,
  provideAppInitializer,
} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, provideRouter } from '@angular/router';

import { DOCUMENT } from '@angular/common';
import { provideAnimations } from '@angular/platform-browser/animations';
import { ModalService } from '@coreui/angular';
import { provideToastr } from 'ngx-toastr';
import { routes } from './app.routes';
import { tokenInterceptor } from './core/http-interceptor.interceptor';
import { initializeAppFactory } from './core/initializeAppFactory';
import { TenantsService } from './services/tenants.service';

export const appConfig: ApplicationConfig = {
  providers: [
    provideAnimations(), // required animations providers
    provideToastr({}),
    provideRouter([...routes]),
    // provideRouter(routes),
    // provideAppInitializer(() => initializeAppFactory(inject(TenantsService))),
    ModalService,
    importProvidersFrom(RouterModule, FormsModule, ReactiveFormsModule),
    provideAppInitializer(() => initializeAppFactory(inject(TenantsService), inject(DOCUMENT))),
    provideHttpClient(withInterceptors([tokenInterceptor])),
  ],
};
