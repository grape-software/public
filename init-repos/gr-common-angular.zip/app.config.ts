import * as jsonData from '../../public/web-init.json';

import { HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import {
  ApplicationConfig,
  inject,
  provideAppInitializer,
  provideZoneChangeDetection,
} from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { DOCUMENT } from '@angular/common';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideRouter } from '@angular/router';
import { provideToastr } from 'ngx-toastr';
import { routes } from './app.routes';
import { sharedProviders } from './core/core.providers';
import { TokenInterceptor } from './core/http-interceptor.interceptor';
import { TenantsService } from './services/tenants.service';
import { WebConfig } from './WebConfig';

async function initializeAppFactory(
  tenantsService: TenantsService,
  document: Document,
): Promise<unknown> {
  const r: any = await firstValueFrom(tenantsService.initConfig());
  const config = Object.assign(new WebConfig(), jsonData); // jsonData as WebConfig;
  if (r) {
    const webInitParam = Object.assign(new WebConfig(), JSON.parse(r.config));
    if (webInitParam) {
      Object.assign(config, webInitParam); // hace un merge de los atributos de webInitParam en config
    }
    config.tenantId = r.tenantId;
  }
  tenantsService.config = config; // para actualizar lo que se leyo de la base
  localStorage.setItem('webConfig', JSON.stringify(config));
  if (config.styleSheetName) {
    const styleLink = document.createElement('link');
    styleLink.rel = 'stylesheet';
    if (config.styleSheetName.startsWith('http')) {
      styleLink.href = config.styleSheetName;
    } else {
      styleLink.href = `assets/css/${config.styleSheetName}.css`;
    }
    document.head.appendChild(styleLink);
  }

  return true;
}

export const appConfig: ApplicationConfig = {
  providers: [
    provideAnimations(), // required animations providers
    provideToastr({}),
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter([...routes]),
    // provideRouter(routes),
    // provideAppInitializer(() => initializeAppFactory(inject(TenantsService))),
    ...sharedProviders,
    provideAppInitializer(() => initializeAppFactory(inject(TenantsService), inject(DOCUMENT))),
    provideHttpClient(
      // DI-based interceptors must be explicitly enabled.
      withInterceptorsFromDi(),
    ),
    { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true },
  ],
};
